## ----setup, include=FALSE, cache=FALSE-----------------------------------
library(knitr)
my_pdf = function(file, width, height) {
  pdf(file, width = width, height = height, pointsize = 8)
}

## ------------------------------------------------------------------------
library("CostTrajectory")

## ----eval=FALSE----------------------------------------------------------
#  citation("CostTrajectory")

## ------------------------------------------------------------------------
data <- CostTrajectory_simulate_data(n=50)
head(data)

fit <- CostTrajectory(time=data$time, surv=data$surv, cost=data$Y,
                      id=data$id, status=data$status, usecensor, ndx=5, deg=2, pord=2,
                      lambdas=rep(1e-5,3), coefstart=NULL, usecensor=TRUE,
                      control=list(), correlation='compound')


## ----fig.keep='none'-----------------------------------------------------
plot(fit)
summary(fit)

## population mean plot-----------------------------------------------------

fit.popmean <- CostTrajectory_PopulationMean(data)
Z0 <- matrix(NA,tau+2,tau)
for(i in 1:tau){
  for(j in 1:i){
    Z0[i,j] <-  fit.popmean$Y[fit.popmean$death == i & fit.popmean$time == j]
  }
}
for(j in 1:tau)
  Z0[tau+2,j] <- fit.popmean$Y[fit.popmean$death == tau+1 & fit.popmean$time == j]

image2D(x=1:tau,y=1:(tau+2), t(Z0), main = 'Population mean heatmap',
        xlab = 'time',ylab = 'survival')

persp3D(y=1:tau,x=1:(tau+2), z = Z0, main = 'Population mean surface',
        ylab = 'time',xlab = 'survival', zlab='Cost',
        clab = "Cost",theta=30,phi=25)


## beautiful plot-----------------------------------------------------
library(ggplot2)
library(wesanderson)
library(scales)
library(gridExtra)
library(plotly)
library(rayshader)
ndx <- 5; deg <- 2
tau <- fit$tau
x <- 1:tau; y <- 1:tau
Bi <- fit$test$B
theta1 <- matrix(fit$coefficent$theta,ncol=1)
theta2 <- matrix(fit$coefficent.init$theta,ncol=1)
dat.test <- fit$test$data
s.lst <- c(c(2,4,6,8)*10,101)
vv1 = object$coefficent$variance$variance
vv2 = object$coefficent.init$variance$variance

Bi1 <- cbind(Bi, matrix(0,nrow(Bi),ndx+deg))
se1 = sqrt(diag(Bi1 %*% vv1 %*% t(Bi1)))
se2 = sqrt(diag(Bi1 %*% vv2 %*% t(Bi1)))
yhat1 <- as.vector(Bi %*% theta1)
yhat2 <- as.vector(Bi %*% theta2)
yhat0 <- fit.popmean$Y

pal <- wes_palette("Zissou1", 10, type = "continuous")
dat.test$Y0 <- as.array(yhat0)
dat.test$Y1 <- as.array(yhat1)
dat.test$Y2 <- as.array(yhat2)
idx <- which(dat.test$death %in% s.lst)

pt1d <- data.frame(dat.test, group = paste0('Fitted', dat.test$id),
                   Stage = rep('Fitted',nrow(dat.test)),
                   YY=yhat1,Ylb = yhat1-1.96*se1,Yub = yhat1+1.96*se1)
pt2d <- data.frame(dat.test, group = paste0('Initial', dat.test$id),
                   Stage = rep('Initial',nrow(dat.test)),
                   YY=yhat2,Ylb = yhat2-1.96*se1,Yub = yhat1+1.96*se2)
tau=100
ptd <- rbind(pt1d[idx,],pt2d[idx,])
ptd$id[ptd$id==101] <- '100+'
ptd$id <- factor(ptd$id,levels=c("20","40","60","80","100+" ))

ptd$Method <- 'Estimate'
xx <- ptd[,c('death','time','YY','Stage','Ylb','Yub','id')]
p=ggplot(xx)+geom_line(aes(time,YY,group=Stage,color=Stage,linetype=Stage))+
  geom_ribbon(data=subset(xx, 0 <= xx$time & xx$time <= tau),
              aes(x=time,xmin=0,xmax=tau,ymin=Ylb,ymax=Yub,
                  group=Stage,fill=Stage), alpha=0.3) +
  scale_fill_manual(values = c("blue", "red", 'green'))  +ylim(0,15)+
  xlab('Time')+ylab('Cost')+
  scale_x_continuous(breaks = seq(0,tau, by = 10)) +
  scale_color_manual(values = c("blue", "red"))+
  theme(panel.background = element_rect(fill='white',color='black'),
        panel.grid.major = element_line(colour = "lightgrey",size=.2),
        legend.position = "none",
        legend.box = "vertical",
        plot.title = element_text(hjust = 0.5)) +
  facet_grid(rows = vars(id))
ggplotly(p)




## heatmap-----------------------------------------------------
ptd <- rbind(pt1d,pt2d)
ptd$id <- as.factor(ptd$id)
yy <- ptd[ptd$death>tau,]
ptd <- ptd[ptd$death<=tau,]
yy$death <- tau+5
yy2 <- yy
for(i in (tau+6:15)){
  yy1 <- yy; yy1$death <- i
  yy2 <- rbind(yy2,yy1)
}
ptd1 <- rbind(ptd, yy2)
p <- ggplot(ptd1,aes(y=death,x=time))+
  geom_raster(aes(fill=YY)) +
  geom_contour(aes(z=Y),color='black',breaks=c(3,6,9))+
  xlab('Time')+ylab('Survival ')+
  scale_fill_gradientn(colours = pal, limits=c(0,18),name='Cost\n',
                       values = rescale(c(0,8,10,18),
                                        from = c(0,18)))+
  theme(panel.background = element_rect(fill='white',color='black'),
        plot.title = element_text(hjust = 0.5), legend.key.height = unit(1, "cm")
  )+
  scale_x_continuous(breaks = seq(0,tau, by = 10)) +
  scale_y_continuous(breaks = seq(0,tau, by = 10)) +
  facet_grid(cols = vars(Stage))
ggplotly(p)

# 3D plot ----------------------------------------------------------


xx <- ptd[ptd$Stage=='Initial',]#Distant
y = 1:(tau+15); x=1:tau

z <- matrix(NA, tau,tau+15)
for(i in 1:tau) z[(1:i),i] <- ptd1$YY[ptd1$group == paste0('Fitted',i)]#Local/Regional
for(i in (6:15)+tau) z[,i] <- ptd1$YY[(ptd1$group == paste0('Fitted',tau+1)) & (ptd1$death==i)]
p <- plot_ly(x=y, y=x, z=z,colors = colorRamp(pal,bias=2,alpha=0.7),
             type = 'surface',
             contours = list(
               x = list(show = TRUE, start = 20, end = tau, size = 20, color = 'white'),
               y = list(show = TRUE, start = 20, end = tau, size = 20, color = 'white'),
               z = list(show = TRUE, start = 3, end = 15, size = 1, color = 'white'))) %>% layout(
                 scene = list(
                   camera=list(
                     eye = list(x=2, y=1, z=.5)
                   )
                 )
               ) %>% layout(scene = list(yaxis = list(title='Time',
                                                      tickvals = seq(20,tau,20)),
                                         xaxis = list(title='Survrival',
                                                      tickvals = seq(20,tau,20)),
                                         zaxis = list(title='Cost',
                                                      tickvals = seq(0,15,5))))
p
