#' Fit longitudinal medical cost trajectory
#'
#' The \code{CostTrajectory} function fits two-dimensional P-splines estimating
#' equations of the input data of degree and order fixed by the user.
#' Specifically tailored to the cost data.
#'
#'
#' @param time vector for the measurement time of costs.
#' @param surv vector for the observed survival time of costs. The length of '"surv"'  should be the same as the number of observations.
#' @param cost vector for the observed monthly costs.
#' @param id vector for the identifier of each subject. The length of '"id"'  should be the same as the number of observations.
#' @param status vector for the survival status at the observed survival time, death (1) or censored (0).
#' @param ndx vector with the number of internal knots-1 for each axis, default is [5, 5].
#' @param deg vector with the degree of the B-splines for each axis default is [2, 2].
#' @param pord vector with the order of differences for each axis. Default: [2, 2].
#' @param lambda vector with smoothing parameters, possibly three for axis (optional).
#' @param coefstart an optional matrix of starting coefficients.
#' @param usecensor a bool to decide whether to use censored cost data, default is TRUE.
#' @param control a list of control parameters. See \code{Details}.
#' @param correlation a character string specifying the correlation structure. The following are permitted: '"independence"', '"compound"' and '"ar1"'
#' @param varfunc a character string specifying the variance structure. The following are permitted: '"constant"', '"spline"' and '"linear"'
#'
#'
#' @return An object of type 'CostTrajectory'
#' @export
#'
#' @examples
#' data <- CostTrajectory_simulate_data(n=50)
#' #     id time   surv   status   cost
#' #  1  1    1    1      1        11.03952
#' #  2  2    1    2      1        12.96982
#' #  3  2    2    2      1        13.35871
#' ndx <- 5; deg <- 2; pord <- 2
#' lambdas <- rep(1e-5,3)
#' coefstart <- NULL; control <- list()
#' correlation <- 'compound'; usecensor <- TRUE
#' CostTrajectory(time=data$time, surv=data$surv, cost=data$Y,
#'                id=data$id, status=data$status, ndx, deg, pord,
#'                lambdas, coefstart, usecensor, control, correlation)
#'

CostTrajectory <-
  function(time, surv, cost, id=NULL, status=NULL, ndx=5, deg=2, pord=2,
           lambdas=c(1E-5,1E-5,1E-5), coefstart=NULL, usecensor = TRUE,
           control=list(), correlation='compound', varfunc = 'spline'){
    ## checkings:
    if(is.null(id)){
      id <- 1:length(time)
    }
    if(is.null(status)){
      status <- rep(1, length(time))
    }

    check <-  CostTrajectory_checker(time, surv, cost, id, status, ndx, deg, pord,
                                     lambdas, coefstart, control, correlation, varfunc)
    tau <- max(check$surv[check$status==1])
    time <- check$time / tau
    surv <- check$surv / tau
    cost <- check$cost
    time[is.nan(time)] <- 0;surv[is.nan(surv)] <- 0;cost[is.nan(cost)] <- 0
    id <- check$id
    status <- check$status
    ndx <- check$ndx
    deg <- check$deg
    pord <- check$pord
    MON <- check$control$MON
    TOL1 <- check$control$TOL1
    TOL2 <- check$control$TOL2
    RANGE <- check$control$RANGE
    MAX.IT <- check$control$MAX.IT
    call <- match.call()
    if(sum(status == 0 & surv < 1)==0) usecensor <- FALSE
    # fit hazard function by P-spline
    surv.out  <- CostTrajectory_survival(surv0=surv[!duplicated(id)],
                                         status0=status[!duplicated(id)],
                                         MON, TOL1, MAX.IT, ndx, deg,
                                         lambda = lambdas[1],
                                         usecensor = usecensor)

    # get design matrix and survival
    design <- CostTrajectory_design(time, surv, cost, id, status, ndx, deg,
                                    usecensor, surv.out)

    x=design$x; y=design$y; z=design$z;
    id=design$id; wei=design$wei; delta=design$delta;
    B=design$B; dB=design$dB; surv.diff=design$surv

    ## General initialize:
    idx.init <- which( status==1 | (status == 0 & y == 1))
    if(is.null(coefstart)){
      theta.init <- CostTrajectory_estimate(B[idx.init,], y[idx.init], z[idx.init],
                                        id[idx.init], status[idx.init], usecensor,
                                        varfunc = 'constant', theta.old = NULL,
                                        ndx, deg, pord, lambdas, MON, MAX.IT, correlation)
    }else{
      theta.init <- coefstart
    }


    theta <- CostTrajectory_estimate(B, y, z, id, status,usecensor,
                                varfunc = varfunc, theta.old = theta.init,
                                ndx, deg,  pord,lambdas, MON, MAX.IT, correlation)

    variance.init <- CostTrajectory_variance(B[idx.init,], id[idx.init], z[idx.init],
                                             status[idx.init], y[idx.init],
                                             dB, surv.out,
                                             varfunc = 'constant', theta.init,
                                             lambdas, correlation, ndx, deg, pord)

    variance <- CostTrajectory_variance(B, id, z, status, y,
                                        dB, surv.out,
                                        varfunc = varfunc, theta,
                                        lambdas, correlation, ndx, deg, pord)

    data.test.design <- CostTrajectory_test_design(ndx, deg, n=tau+1)

    # calculate final GCV

    idx.sts <- which(status == 1)
    idx.lts <- which(status == 0 & y == 1)
    id.sts.unique <- unique(id[idx.sts])
    id.lts.unique <- unique(id[idx.lts])

    gcv <- GCV(theta, theta0=NULL, idx.init, ndx, deg, pord,
               variance$rho.sts, variance$rho.lts,
               B, z, id, idx.sts, idx.lts,
               id.sts.unique, id.lts.unique, correlation)
    object <- list(
      ## observed values
      x=x, y=y, z=z, n=length(unique(id)),
      m1=length(unique(id[which(status == 0 & y < 1)])),
      m2=length(unique(id[which(status == 0 & y == 1)])),
      tau=tau, time=time, surv=surv, cost=cost,
      ## smoothing specifications
      ndx=ndx, deg=deg, pord=pord, lambdas=lambdas,
      ## bases
      B=B, tolerance=TOL1,
      ## coefficients
      coefficent.init = list(theta=theta.init, variance = variance.init),
      coefficent = list(theta=theta, variance=variance),
      test = data.test.design, GCV=gcv
    )
    class(object) <- "CostTrajectory"
    object
  }
