#' Calculate survival function to fit medical cost trajectory
#'
#' The \code{CostTrajectory_variance} function calculate the variance function for
#' \code{CostTrajectory} function.
#'
#'
#' @param surv0 vector for the observed survival time of costs.
#' @param status0 vector for the survival status at the observed survival time, death (1) or censored (0).
#' @param id vector for the identifier of each subject. The length of '"id"'  should be the same as the number of observations.
#' @param ndx vector with the number of internal knots-1 for each axis, default is [5, 5].
#' @param deg vector with the degree of the B-splines for each axis default is [2, 2].
#' @param MON monitor indicator, default is FALSE.
#' @param TOL1 tolerance for convergence criteria, default is 1E-4.
#' @param usecensor a bool to decide whether to use censored cost data, default is TRUE.
#' @param MAX.IT maximum number of iterations, default is 50.
#'
#' @return A list containing survival arguments for the CostTrajectory function
#' @export
#'
#' @examples
#' surv0 <- 1:11
#' status0 <- c(rep(1,10),1)
#' MON <- FALSE; TOL1 <- 1E-4; MAX.IT <- 5
#' ndx <- 5; deg <- 2; pord <- 2
#' lambda <- 1e-5; usecensor <- TRUE
#' CostTrajectory_variance(B, id, z, status, y, dB, surv.out,
#'                         varfunc, theta, lambdas, correlation,
#'                         ndx, deg, pord)

CostTrajectory_variance <- function(B, id, z, status, y, dB, surv.out,
                                    varfunc, theta, lambdas, correlation,
                                    ndx, deg, pord){
  nbeta <- length(surv.out$beta)
  ntheta <- length(theta)
  idx.theta.sts <- 1:(ndx+deg)^2
  idx.theta.lts <- (1+(ndx+deg)^2):ntheta
  ntheta.sts <- length(idx.theta.sts)
  ntheta.lts <- length(idx.theta.lts)

  idx.sts <- which(status == 1)
  idx.lts <- which(status == 0 & y == 1)
  idx.cen <- which(status == 0 & y < 1)

  id.sts <- id[idx.sts]
  id.lts <- id[idx.lts]
  id.cen <- id[idx.cen]
  id.unique <- unique(id)
  id.cen.unique <- unique(id.cen)

  ## penalty stuff
  D <- diff(diag(ndx+deg), diff=pord)
  Px.sts <- kronecker(diag(ndx+deg), t(D) %*% D)
  Py.sts <- kronecker(t(D) %*% D, diag(ndx+deg))
  P.lts <- t(D) %*% D
  DtD <- list(Px.sts, Py.sts, P.lts)

  Penalty <- bdiag(lambdas[1] * DtD[[1]]+lambdas[2] * DtD[[2]],
                   lambdas[3] * DtD[[3]] )

  zhat <- c(B %*% theta)
  zhat.sts <- zhat[idx.sts]
  zhat.lts <- zhat[idx.lts]
  err <- z - zhat
  err.sts <- err[idx.sts]
  err.lts <- err[idx.lts]

  logerr.sq.sts = log(err.sts^2)
  logerr.sq.lts = log(err.lts^2)

  if(varfunc == 'constant'){
    varmodel.sts <- gam(logerr.sq.sts ~ 1)
    varmodel.lts <- gam(logerr.sq.lts ~ 1)
  }else if(varfunc == 'linear'){
    varmodel.sts <- gam(logerr.sq.sts ~ (zhat.sts))
    varmodel.lts <- gam(logerr.sq.lts ~ (zhat.lts))
  }else{
    varmodel.sts <- gam(logerr.sq.sts ~ s(zhat.sts))
    varmodel.lts <- gam(logerr.sq.lts ~ s(zhat.lts))
  }
  if(correlation=="compound"){
    corrmodel.sts <- gls(err.sts ~ 1, correlation=corCompSymm(form=~1|id.sts))  # use this one
    corrmodel.lts <- gls(err.lts ~ 1, correlation=corCompSymm(form=~1|id.lts))  # use this one
  }else if(correlation=="AR") {
    corrmodel.sts <- gls(err.sts ~ 1, correlation=corAR1(form=~1|id.sts))  # use this one
    corrmodel.lts <- gls(err.lts ~ 1, correlation=corAR1(form=~1|id.lts))  # use this one
  }
  # phi.new <- lm$sigma^2
  rho.new.sts <- coef(corrmodel.sts$modelStruct$corStruct, unconstrained=FALSE)
  rho.new.lts <- coef(corrmodel.lts$modelStruct$corStruct, unconstrained=FALSE)

  A.sts <- c(exp(predict(varmodel.sts,
                         newdata=data.frame(zhat.sts=zhat))))
  A.lts <- c(exp(predict(varmodel.lts,
                         newdata=data.frame(zhat.lts=zhat))))

  XtXY <- foreach( i = id.unique, .combine = '+' ) %do% {
    idx.i <- which(id==i)
    ni <- length(idx.i)
    B.i.sts <- matrix(B[idx.i,idx.theta.sts], nrow=ni)
    B.i.lts <- matrix(B[idx.i,idx.theta.lts], nrow=ni)
    err.i <- err[idx.i]
    if(correlation=="compound"){
      Ri.sts <- matrix(rho.new.sts, ni, ni)
      Ri.lts <- matrix(rho.new.lts, ni, ni)
      diag(Ri.sts) <- diag(Ri.lts) <- 1
    }else if(correlation=="AR"){
      Ri.sts <- rho.new.sts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni,
                                       byrow = TRUE) - (1:ni - 1))
      Ri.lts <- rho.new.lts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni,
                                       byrow = TRUE) - (1:ni - 1))
    }
    Ai.sts <- A.sts[idx.i]
    Ai.lts <- A.lts[idx.i]
    if(ni==1) {Ai.sts <- matrix(Ai.sts,nrow=1); Ai.lts <- matrix(Ai.lts,nrow=1)}
    Ai_sqrt.sts <- diag(sqrt(Ai.sts))
    Sigma.sts <- Ai_sqrt.sts %*% Ri.sts %*% Ai_sqrt.sts
    Sigma_inv.sts <- solve(Sigma.sts)
    Ai_sqrt.lts <- diag(sqrt(Ai.lts))
    Sigma.lts <- Ai_sqrt.lts %*% Ri.lts %*% Ai_sqrt.lts
    Sigma_inv.lts <- solve(Sigma.lts)
    DS <- rbind(t(B.i.sts) %*% Sigma_inv.sts,
                t(B.i.lts) %*% Sigma_inv.lts)
    meat.i_sqrt <- c(c(DS %*% err.i),
                     surv.out$var_surv$gradn[,i])

    out.i <- cbind(rbind(DS %*% cbind(B.i.sts, B.i.lts),
                         matrix(0, nbeta, ntheta)),
                   tcrossprod(meat.i_sqrt))
    # if(i %in% id.cen.unique){
    #   z.i <- matrix(z[idx.i], ncol=1)
    #   idx.cen.i <- which(id.cen==i)
    #   dB.i <- dB[,,idx.cen.i]
    #   out.i[1:nbeta + ntheta, 1:ntheta] <- t(apply(dB.i, 1, function(xx)
    #     rbind(xx[idx.theta.sts,] %*% Sigma_inv.sts,
    #           xx[idx.theta.lts,] %*% Sigma_inv.lts) %*% (z.i - 2 * err.i)))
    # }
    out.i
  }
  bread <- meat <- matrix(0, ntheta + nbeta, ntheta + nbeta)
  bread[, 1:ntheta] <- XtXY[,1:ntheta]
  bread[1:ntheta, 1:ntheta] <- bread[1:ntheta, 1:ntheta] + 2*as.matrix(Penalty)
  bread[1:nbeta + ntheta, 1:nbeta + ntheta] <- surv.out$var_surv$hess
  meat <- XtXY[,ntheta+1:(ntheta+nbeta)]

  bread_inv <- solve(bread)

  variance <- bread_inv %*% meat %*% bread_inv
  return(list(variance = variance,
              varmodel.sts=varmodel.sts, varmodel.lts=varmodel.lts,
              rho.sts=rho.new.sts, rho.lts=rho.new.lts,
              surv = surv.out$beta,
              residuals = err))
}
