#' Plot longitudinal medical cost trajectory
#'
#' The \code{plot.CostTrajectory} function produces three plots for the
#' \code{CostTrajectory} object.
#'
#' @param object an object of class "CostTrajectory" from function \code{CostTrajectory}.
#'
#' @export
#' @example
#' data <- CostTrajectory_simulate_data(n=50)

#' fit <- CostTrajectory(time=data$time, surv=data$surv, cost=data$Y,
#'                       id=data$id, status=data$status, ndx=5, deg=2, pord=2,
#'                       lambdas=rep(1e-5,3), coefstart=NULL, usecensor=TRUE,
#'                       control=list(), correlation='compound')
#' plot(fit)

plot.CostTrajectory <-
  function(object, ...){
    tau <- object$tau
    x <- 1:tau
    y <- 1:tau
    # z0 <- object$test$B %*% object$coefficent$theta
    z1 <- object$test$B %*% object$coefficent$theta
    Z0 <- Z1 <- matrix(NA,tau+2,tau)
    for(i in x){
      for(j in 1:i){
        # Z0[i,j] <- z0[object$test$data$death == i & object$test$data$time == j]
        Z1[i,j] <- z1[object$test$data$death == i & object$test$data$time == j]
      }
    }
    for(j in 1:tau)
      Z1[tau+2,j] <- z1[object$test$data$death == tau+1 & object$test$data$time == j]

    par(mfrow = c(1,3), mar = c(4,4,2,2))
    plot(NULL, xlim = c(0,tau), ylim = c(0,max(z1)),
         main = 'Fitted trajectory',
         xlab = 'Time', ylab = 'Cost')
    for(i in seq(10,tau,10)){
      idx <- which(object$test$data$id==i)
      xx <- 1:i; zz <- z1[idx]
      lines(xx, zz, col = i/10)
    }
    idx <- which(object$test$data$id==tau+1)
    xx <- 1:tau; zz <- z1[idx]
    lines(xx, zz, col = 1, lty=2)

    image2D(x=1:tau,y=1:(tau+2), t(Z1), main = 'Fitted heatmap',
            xlab = 'time',ylab = 'survival')
    persp3D(y=1:tau,x=1:(tau+2), z = Z1, main = 'Fitted surface',
            ylab = 'time',xlab = 'survival', zlab='Cost',
            clab = "Cost",theta=30,phi=25)

  }
