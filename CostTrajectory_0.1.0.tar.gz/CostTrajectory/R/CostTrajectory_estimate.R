#' Estimate parameters for longitudinal medical cost trajectory
#'
#' The \code{CostTrajectory_estimate} function estimate mean and variance parameters.
#'
#'
#' @param B vector for scaled the measurement time of costs.
#' @param y vector for the scaled observed survival time of costs.
#' @param z vector for the observed monthly costs.
#' @param id vector for the identifier of each subject. The length of '"id"'  should be the same as the number of observations.
#' @param status vector for the survival status at the observed survival time, death (1) or censored (0).
#' @param varfunc a character string specifying the variance structure. The following are permitted: '"constant"', '"spline"' and '"linear"'
#' @param theta.old initial value for model parameter, default is NULL.
#' @param ndx vector with the number of internal knots-1 for each axis, default is [5, 5].
#' @param deg vector with the degree of the B-splines for each axis default is [2, 2].
#' @param lambdas vector with smoothing parameters, possibly three for axis (optional).
#' @param MON a \code{control} bool value for monitor status, default is FALSE.
#' @param MAX.IT a value for maximum number of iterations, default is 20
#' @param correlation a character string specifying the correlation structure. The following are permitted: '"independence"', '"compound"' and '"AR"'
#' @param LTS a bool indicator whether to specify long-term survivor group, default is TRUE
#'
#' @return A list containing parameter arguments for the CostTrajectory function
#' @export
#'
#' @examples
#' surv <- id <- Reduce('c',sapply(1:11, function(x) rep(x,x)))
#' y <- surv / max(surv)
#' z <- (time-5)^2*surv/10+rnorm(66,10,1)
#' status <- c(rep(1,55), rep(0,11))
#' MON <- FALSE; TOL1 <- 1E-4; MAX.IT <- 5
#' ndx <- 5; deg <- 2; pord <- 2
#' varfunc <- 'constant'
#' correlation <- 'compound'
#' B <- matrix(rnorm(3696),66,56)
#' lambdas <- rep(1e-5,3)
#' CostTrajectory_estimate(B, y, z, id, status, usecensor, varfunc, theta.old = NULL,
#'                         ndx, deg, lambdas, MON, MAX.IT, correlation, LTS = TRUE)

# library(mgcv)
CostTrajectory_estimate <- function(B, y, z, id, status, usecensor,
                                    varfunc, theta.old = NULL,
                                    ndx, deg, pord, lambdas, MON, MAX.IT,
                                    correlation, LTS = TRUE){

  id.unique <- unique(id)
  n <- length(id.unique)

  ## penalty stuff
  D <- diff(diag(ndx+deg), diff=pord)
  Px.sts <- kronecker(diag(ndx+deg), t(D) %*% D)
  Py.sts <- kronecker(t(D) %*% D, diag(ndx+deg))
  P.lts <- t(D) %*% D
  DtD <- list(Px.sts, Py.sts, P.lts)

  # plot results
  dat.test <- CostTrajectory_test_design(ndx, deg)


  if(is.null(theta.old)){
    if(is.null(lambdas)) {lambda0 <- rep(1e-6,3)}else {lambda0 <- lambdas}
    Penalty <- bdiag(lambda0[1] * DtD[[1]]+lambda0[2] * DtD[[2]],
                     lambda0[3] * DtD[[3]] )

    theta.old <- as.matrix(solve( (t(B) %*% B) / n + Penalty) %*%
                             ( (t(B) %*% z) / n ))
  }
  theta.init <- theta.old
  ntheta <- length(theta.init)
  idx.theta.sts <- 1:(ndx+deg)^2
  idx.theta.lts <- (1+(ndx+deg)^2):ntheta
  ntheta.sts <- length(idx.theta.sts)
  ntheta.lts <- length(idx.theta.lts)

  idx.sts <- which(status == 1)
  idx.lts <- which(status == 0 & y == 1)
  idx.cen <- which(status == 0 & y < 1)

  id.sts <- id[idx.sts]
  id.lts <- id[idx.lts]
  id.cen <- id[idx.cen]

  id.sts.unique <- unique(id.sts)
  id.lts.unique <- unique(id.lts)
  id.cen.unique <- unique(id.cen)

  ## penalty stuff

  if(is.null(lambdas)){
    lambdas_candidate <- 10^c(-6:4)
    lambdas <- select_cost_lambda(Bh, K, eo, Ytilde, w, DtD,
                                 beta.new = NULL,
                                 MON, TOL1, MAX.IT, ndx, deg, pord, n,
                                 lambdas_candidate)
  }

  Penalty <- bdiag(lambdas[1] * DtD[[1]]+lambdas[2] * DtD[[2]],
                   lambdas[3] * DtD[[3]])

  theta <- fit_cost(B, theta.old, z, id, varfunc,usecensor,
                    idx.sts, idx.lts,
                    id.sts, id.lts,
                    id.sts.unique, id.lts.unique, id.cen.unique,
                    idx.theta.sts, idx.theta.lts,
                    Penalty, dat.test, correlation,
                    MON,TOL1, MAX.IT, ndx, deg, n,
                    ntheta.sts, ntheta.lts, ntheta)

  return( theta )
}



select_cost_lambda <- function(Bh, K, eo, Ytilde, w, DtD,
                               beta.new = NULL,
                               MON, TOL1, MAX.IT, ndx, deg, pord, n,
                               lambdas = c(0,10^seq(-6,4,1))){


  Penalty <- matrix(0, nrow=ntheta, ncol=ntheta)

  theta0 <- fit_cost(B, theta.old, z, id, varfunc,usecensor,
                     idx.sts, idx.lts,
                     id.sts, id.lts,
                     id.sts.unique, id.lts.unique, id.cen.unique,
                     idx.theta.sts, idx.theta.lts,
                     Penalty, dat.test, correlation,
                     MON,TOL1, MAX.IT, ndx, deg, n,
                     ntheta.sts, ntheta.lts, ntheta)

  lambdass.rough <- lapply(1:3, function(x) 10^seq(-6,6,1))
  GCVs.rough <- lambda_search(B, theta.old, z, id, varfunc,
                              id.sts.unique, id.lts.unique, id.cen.unique,
                              idx.theta.sts, idx.theta.lts,
                              Penalty, Bi, dat.test, theta0,
                              MON, TOL1, MAX.IT, ndx, deg, pord,
                              DtD, lambdass.rough)
  idx.rough <- which(GCVs.rough == min(GCVs.rough), arr.ind = TRUE)

  # fine search
  lambdass.fine <- list()
  for(i in 1:3) lambdass.fine[[i]] <- 10^seq(log10(lambdass.rough[[i]][idx.rough[i]])-2,
                                             log10(lambdass.rough[[i]][idx.rough[i]])+2)

  nlambdas <- sapply(lambdass, length)
  GCVs <- array(0,nlambdas)
  GCVs <- lambda_search(B, theta.old, z, id, varfunc,
                        id.sts.unique, id.lts.unique, id.cen.unique,
                        idx.theta.sts, idx.theta.lts,
                        Penalty, Bi, dat.test, theta0,
                        MON, TOL1, MAX.IT, ndx, deg,
                        DtD, lambdass.fine)
  idx <- which(GCVs == min(GCVs), arr.ind = TRUE)
  lambda.choose <- sapply(1:3, function(i) lambdass.fine[[i]][idx[i]])

  return(lambda.choose)
}

lambda_search <- function(B, theta.old, z, id, varfunc,
                          id.sts.unique, id.lts.unique, id.cen.unique,
                          idx.theta.sts, idx.theta.lts,
                          Penalty, Bi, dat.test, theta0,
                          MON, TOL1, MAX.IT, ndx, deg, pord,
                          ntheta.sts, ntheta.lts, ntheta,
                          DtD, lambdass){
  lambdass <- 10^seq(-6,4)
  nlambdas <- length(lambdass)#sapply(lambdass, length)
  GCVs <- array(0,dim=nlambdas)

  for(i in 1:nlambdas){
    Penalty <- lambdass[i] * as.matrix(bdiag(  DtD[[1]]+ DtD[[2]], DtD[[3]] ))

    theta <- fit_cost(B, theta.old, z, id, varfunc,usecensor,
                      idx.sts, idx.lts,
                      id.sts, id.lts,
                      id.sts.unique, id.lts.unique, id.cen.unique,
                      idx.theta.sts, idx.theta.lts,
                      Penalty, dat.test, correlation,
                      MON,TOL1, MAX.IT, ndx, deg, n,
                      ntheta.sts, ntheta.lts, ntheta)

    GCVs[i] <- GCV(theta, theta0, idx.init, ndx, deg, pord,
                   rho.sts, rho.lts,
                   B, z, id, idx.sts, idx.lts,
                   id.sts.unique, id.lts.unique, correlation)
  }
  return(GCVs)
}


GCV <- function(theta, theta0=NULL, idx.init, ndx, deg, pord,
                rho.sts, rho.lts,
                B, z, id, idx.sts, idx.lts,
                id.sts.unique, id.lts.unique, correlation){
  nn <- length(id.sts.unique)+length(id.lts.unique)
  if(is.null(theta0)){
    ntheta <- length(theta); n <- length(unique(id))
    D <- diff(diag(ndx+deg), diff=pord)
    Px.sts <- kronecker(diag(ndx+deg), t(D) %*% D)
    Py.sts <- kronecker(t(D) %*% D, diag(ndx+deg))
    P.lts <- t(D) %*% D
    DtD <- list(Px.sts, Py.sts, P.lts)
    lambda0 <- rep(1e-6,3)
    Penalty <- bdiag(lambda0[1] * DtD[[1]]+lambda0[2] * DtD[[2]],
                     lambda0[3] * DtD[[3]] )

    B.init <- B[idx.init,]; z.init <- z[idx.init]
    theta0 <- as.matrix(solve( (t(B.init) %*% B.init) / nn + Penalty) %*%
                             ( (t(B.init) %*% z.init) / nn ))
  }

  zhat <- c(B %*% theta)
  zhat.sts <- zhat[idx.sts]
  zhat.lts <- zhat[idx.lts]

  err <- z - zhat
  err.sts <- err[idx.sts]
  err.lts <- err[idx.lts]

  Dev.df.sts <- foreach( l = id.sts.unique, .combine = '+' ) %do% {
    idx.i <- which(id==l)
    ni <- length(idx.i)
    err.i <- err[idx.i]
    if(correlation=="compound"){
      Ri.sts <- matrix(rho.sts, ni, ni)
      diag(Ri.sts) <- 1
    }else if(correlation=="AR"){
      Ri.sts <- rho.sts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni, byrow = TRUE) - (1:ni - 1))
    }
    Dev <- t(err.i) %*% Ri.sts %*% err.i
    df <- ni^2/sum(Ri.sts)
    c(Dev, df)
  }

  Dev.df.lts <- foreach( l = id.lts.unique, .combine = '+' ) %do% {
    idx.i <- which(id==l)
    ni <- length(idx.i)
    err.i <- err[idx.i]
    if(correlation=="compound"){
      Ri.lts <- matrix(rho.lts, ni, ni)
      diag(Ri.lts) <- 1
    }else if(correlation=="AR"){
      Ri.lts <- rho.lts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni, byrow = TRUE) - (1:ni - 1))
    }
    Dev <- t(err.i) %*% Ri.lts %*% err.i
    df <- ni^2/sum(Ri.lts)
    c(Dev, df)
  }
  Dev <- Dev.df.sts[1] + Dev.df.lts[1]
  df <- Dev.df.sts[2] + Dev.df.lts[2]
  GCV <- Dev / nn / (1-ntheta * sqrt(sum(theta^2)) / sqrt(sum(theta0^2)) / df)^2
  GCV
}

fit_cost <- function(B, theta.old, z, id, varfunc, usecensor,
                     idx.sts, idx.lts,
                     id.sts, id.lts,
                     id.sts.unique, id.lts.unique, id.cen.unique,
                     idx.theta.sts, idx.theta.lts,
                     Penalty, dat.test, correlation,
                     MON,TOL1, MAX.IT, ndx, deg, n,
                     ntheta.sts, ntheta.lts, ntheta){

  iterate <- 0
  repeat{
    zhat.old <- c(B %*% theta.old)
    zhat.old.sts <- zhat.old[idx.sts]
    zhat.old.lts <- zhat.old[idx.lts]

    err <- z - zhat.old
    err.sts <- err[idx.sts]
    err.lts <- err[idx.lts]

    logerr.sq.sts = log(err.sts^2)
    logerr.sq.lts = log(err.lts^2)

    if(varfunc == 'constant'){
      varmodel.sts <- gam(logerr.sq.sts ~ 1)
      varmodel.lts <- gam(logerr.sq.lts ~ 1)
    }else if(varfunc == 'linear'){
      varmodel.sts <- gam(logerr.sq.sts ~ (zhat.old.sts))
      varmodel.lts <- gam(logerr.sq.lts ~ (zhat.old.lts))
    }else{
      varmodel.sts <- gam(logerr.sq.sts ~ s(zhat.old.sts))
      varmodel.lts <- gam(logerr.sq.lts ~ s(zhat.old.lts))
    }
    if(correlation=="compound"){
      corrmodel.sts <- gls(err.sts ~ 1, correlation=corCompSymm(form=~1|id.sts))
      corrmodel.lts <- gls(err.lts ~ 1, correlation=corCompSymm(form=~1|id.lts))
    }else if(correlation=="AR") {
      corrmodel.sts <- gls(err.sts ~ 1, correlation=corAR1(form=~1|id.sts))
      corrmodel.lts <- gls(err.lts ~ 1, correlation=corAR1(form=~1|id.lts))
    }
    rho.new.sts <- coef(corrmodel.sts$modelStruct$corStruct, unconstrained=FALSE)
    rho.new.lts <- coef(corrmodel.lts$modelStruct$corStruct, unconstrained=FALSE)

    A.sts <- c(exp(predict(varmodel.sts,
                           newdata=data.frame(zhat.old.sts=zhat.old))))
    A.lts <- c(exp(predict(varmodel.lts,
                           newdata=data.frame(zhat.old.lts=zhat.old))))

    XtXY.sts <- Reduce('+',  foreach( i = id.sts.unique ) %do% {
      idx.i <- which(id==i)
      ni <- length(idx.i)
      B.i.sts <- matrix(B[idx.i,idx.theta.sts], nrow=ni)
      z.i <- matrix(z[idx.i], ncol=1)

      if(correlation=="compound"){
        Ri.sts <- matrix(rho.new.sts, ni, ni)
        diag(Ri.sts) <- 1
      }else if(correlation=="AR"){
        Ri.sts <- rho.new.sts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni, byrow = TRUE) - (1:ni - 1))
      }
      Ai <- A.sts[idx.i]
      if(ni==1) Ai <- matrix(Ai,nrow=1)
      Ai_sqrt <- diag(sqrt(Ai))
      Sigma <- Ai_sqrt %*% Ri.sts %*% Ai_sqrt
      Sigma_inv <- solve(Sigma)
      t(B.i.sts) %*% Sigma_inv %*% cbind(B.i.sts, z.i)
    })

    XtXY.lts <- Reduce('+', foreach( i = id.lts.unique ) %do% {
      idx.i <- which(id==i)
      ni <- length(idx.i)
      B.i.lts <- matrix(B[idx.i,idx.theta.lts], nrow=ni)
      z.i <- matrix(z[idx.i], ncol=1)

      if(correlation=="compound"){
        Ri.lts <- matrix(rho.new.lts, ni, ni)
        diag(Ri.lts) <- 1
      }else if(correlation=="AR"){
        Ri.lts <- rho.new.lts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni, byrow = TRUE) - (1:ni - 1))
      }
      Ai <- A.lts[idx.i]
      if(ni==1) Ai <- matrix(Ai,nrow=1)
      Ai_sqrt <- diag(sqrt(Ai))
      Sigma <- Ai_sqrt %*% Ri.lts %*% Ai_sqrt
      Sigma_inv <- solve(Sigma)
      t(B.i.lts) %*% Sigma_inv %*% cbind(B.i.lts, z.i)
    })

    XtXY.cen <- matrix(0, ntheta, ntheta + 1)
    if(usecensor){
      XtXY.cen <- Reduce('+', foreach( i = id.sts.unique ) %do% {
        idx.i <- which(id==i)
        ni <- length(idx.i)
        B.i.sts <- matrix(B[idx.i,idx.theta.sts], nrow=ni)
        B.i.lts <- matrix(B[idx.i,idx.theta.lts], nrow=ni)
        z.i <- matrix(z[idx.i], ncol=1)

        if(correlation=="compound"){
          Ri.sts <- matrix(rho.new.sts, ni, ni)
          Ri.lts <- matrix(rho.new.lts, ni, ni)
          diag(Ri.sts) <- diag(Ri.lts) <- 1
        }else if(correlation=="AR"){
          Ri.sts <- rho.new.sts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni, byrow = TRUE) - (1:ni - 1))
          Ri.lts <- rho.new.lts^abs(matrix(1:ni - 1, nrow = ni, ncol = ni, byrow = TRUE) - (1:ni - 1))
        }
        Ai.sts <- A.sts[idx.i]
        Ai.lts <- A.lts[idx.i]
        if(ni==1) {Ai.sts <- matrix(Ai.sts,nrow=1); Ai.lts <- matrix(Ai.lts,nrow=1)}
        Ai_sqrt.sts <- diag(sqrt(Ai.sts))
        Sigma.sts <- Ai_sqrt.sts %*% Ri.sts %*% Ai_sqrt.sts
        Sigma_inv.sts <- solve(Sigma.sts)
        Ai_sqrt.lts <- diag(sqrt(Ai.lts))
        Sigma.lts <- Ai_sqrt.lts %*% Ri.lts %*% Ai_sqrt.lts
        Sigma_inv.lts <- solve(Sigma.lts)

        rbind(t(B.i.sts) %*% Sigma_inv.sts,
              t(B.i.lts) %*% Sigma_inv.lts) %*% cbind(B.i.sts, B.i.lts, z.i)
      })
    }

    XtX.sts <- XtXY.sts[,1:ntheta.sts]
    XtY.sts <- XtXY.sts[,ntheta.sts+1]
    XtX.lts <- XtXY.lts[,1:ntheta.lts]
    XtY.lts <- XtXY.lts[,ntheta.lts+1]
    XtX <- bdiag(XtX.sts, XtX.lts)
    XtY <- c(XtY.sts, XtY.lts)
    XtX.cen <- XtXY.cen[, 1:ntheta]
    XtY.cen <- XtXY.cen[, ntheta+1]

    XtX <- (XtX + XtX.cen) / n
    XtY <- (XtY + XtY.cen) / n
    theta.new <- as.numeric( solve(XtX + 2*Penalty) %*% (XtY) )

    iterate <- iterate + 1
    if( Convergence( theta.new, theta.old, MON )  | iterate > MAX.IT ){
      converge <- "Success" ;
      break
    }
    theta.old <- theta.new
  }

  if(MON){
    plot(NULL, xlim = c(0,10), ylim = c(0,40),
         main = "Fitted theta", xlab='time', ylab='Y')
    for(i in 1:10) lines(dat.test$B[which(dat.test$data$death==i),] %*% theta.new, col = i,lty=1) # STS
    lines(dat.test$B[which(dat.test$data$death>10)] %*% theta.new, col=11,lty=2) # LTS
  }

  if(iterate > (MAX.IT-1)) {
    warning(paste("parameter estimates did NOT converge in",
                  MAX.IT,
                  "iterations. Increase MAX.IT in control."))
  }
  return(theta.new)
}

Convergence <- function( new, old, TOL1 = 1E-4, MON = F ){
  n.predictor <- length(new)
  ind <- rep(0, n.predictor)
  for (i in 1:n.predictor) {
    if (new[i] < abs(0.01)){
      ind[i] <- as.numeric( abs(new[i]-old[i]) < TOL1 )
    } else{
      ind[i] <- as.numeric( abs(new[i]-old[i]) / (abs(old[i])+10^(-5)) < TOL1 )
    }
  }
  det <- FALSE
  #cat("Converge number = ",  sum(ind), "\n")
  if(sum(ind) == n.predictor ) det <- TRUE
  det
}
