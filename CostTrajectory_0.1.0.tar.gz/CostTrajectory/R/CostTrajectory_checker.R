#' Fit longitudinal medical cost trajectory
#'
#' The \code{CostTrajectory_checker} function checks whether the input for
#' CostTrajectory are valid
#'
#'
#' @param time vector for the measurement time of costs.
#' @param surv vector for the observed survival time of costs.
#' @param cost vector for the observed monthly costs.
#' @param id vector for the identifier of each subject. The length of '"id"'  should be the same as the number of observations.
#' @param status vector for the survival status at the observed survival time, death (1) or censored (0).
#' @param ndx vector with the number of internal knots-1 for each axis, default is [5, 5].
#' @param deg vector with the degree of the B-splines for each axis default is [2, 2].
#' @param pord vector with the order of differences for each axis. Default: [2, 2].
#' @param lambdas vector with smoothing parameters, possibly three for axis (optional).
#' @param coefstart an optional matrix of starting coefficients.
#' @param control a list of control parameters. See \code{Details}.
#' @param correlation 	a character string specifying the correlation structure. The following are permitted: '"independence"', '"compound"' and '"ar1"'
#' @param varfunc a character string specifying the variance structure. The following are permitted: '"constant"', '"spline"' and '"linear"'
#'
#' @return A list containing CHECKED arguments for the CostTrajectory function
#' @export
#'
#' @examples
#' time <- Reduce('c',sapply(1:11, function(x) 1:x))
#' surv <- id <- Reduce('c',sapply(1:11, function(x) rep(x,x)))
#' cost <- (time-5)^2*surv/10+rnorm(66,10,1)
#' status <- c(rep(1,55), rep(0,11))
#' ndx <- 5; deg <- 2; pord <- 2
#' lambdas <- rep(1e-5,3)
#' coefstart <- NULL; control <- list()
#' correlation <- 'compound'
#' CostTrajectory_checker(time, surv, cost, id, status, ndx, deg, pord,
#'                        lambdas, coefstart, control, correlation)

CostTrajectory_checker <-
  function(time, surv, cost, id, status, ndx, deg, pord,
           lambdas, coefstart, control, correlation, varfunc){

    m <- length(surv)

    ## about lengths and wrong values
    if (length(time)!=length(surv) | length(time)!=length(id) | length(time)!=length(status) | length(time)!=length(cost))
      stop("Arguments must have same length")
    if (!min(unique(status) %in% 0:1))
      stop('status must be a vector of 0 or 1')
    if (min(deg) < 1 | max(deg) >= 10)
      stop("Wrong value for deg")
    if (min(pord) <= 0 | max(pord) >= 3)
      stop("Wrong value for pord")
    if (min(ndx) < 2 | max(ndx) >= floor(m*.9))
      stop("Wrong value for ndx")
    ## impossible values for lambdas
    lambdas.check <- is.null(lambdas)
    if(!lambdas.check && min(lambdas)<0)
      stop("lambdas must be positive")
    coefstart.check <- is.null(coefstart)
    if(!coefstart.check){
      if(length(coefstart)!=(ndx+deg)*(ndx+deg+1)){
        stop("coefstart must have length equal to (ndx+deg)*(ndx+deg+1)")
      }
    }
    ## setting control-parameters
    con <- list(MON=FALSE, TOL1=1e-04, TOL2=0.5,
                RANGE=10^(-6:4),
                MAX.IT=20)
    nmsC <- names(con)
    con[(namc <- names(control))] <- control
    if (length(noNms <- namc[!namc %in% nmsC]) > 0)
      warning("unknown names in control: ", paste(noNms, collapse = ", "))
    if(correlation != 'independence' & correlation != 'compound' & correlation != 'ar1')
      stop("correlation structure must be 'independence', 'compound' or 'ar1'")
    if(varfunc != 'constant' & varfunc != 'spline' & varfunc != 'linear')
      stop("varfunc structure must be 'constant', 'spline' or 'linear'")

    ## returning
    llist <- list(time=time, surv=surv, cost=cost,
                  id=id, status=status,
                  ndx=ndx, deg=deg, pord=pord,
                  coefstart=coefstart,
                  control=con)
    llist
  }
