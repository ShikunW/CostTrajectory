#' Summarize longitudinal medical cost trajectory
#'
#' The \code{print.summary.CostTrajectory} function produces summary statistics for the
#' \code{CostTrajectory} object.
#'
#' @param object an object of class "CostTrajectory" from function \code{CostTrajectory}.
#'
#' @export
#'
#' @example
#' data <- CostTrajectory_simulate_data(n=50)

#' fit <- CostTrajectory(time=data$time, surv=data$surv, cost=data$Y,
#'                       id=data$id, status=data$status, ndx=5, deg=2, pord=2,
#'                       lambdas=rep(1e-5,3), coefstart=NULL, usecensor=TRUE,
#'                       control=list(), correlation='compound')
#' summary(fit)
summary.CostTrajectory <-
  function(object, digits=max(3, getOption("digits")-3), ...){
    if(!is.null(cl <- object$call)){
      cat("Call:\n")
      dput(cl, control=NULL)
    }
    cat("\nNumber of Observations                        :", object$n, "\n")
    cat("           of which maximum follow-up time tau:", object$tau, "\n")
    cat("                     long-term survivors (LTS):", object$m2, "(",  round(object$m2/object$n*100,2), "% ) \n")
    cat("                         censored prior to tau:", object$m1, "(",  round(object$m1/object$n*100,2), "% ) \n")
    cat("(Selected) smoothing parameters              ", "\n")
    cat("                                 over time-axis:", format(signif(object$lambdas[1], 5)), "\n")
    cat("                                 over surv-axis:", format(signif(object$lambdas[2], 5)), "\n")
    cat("                                 over LTS -axis:", format(signif(object$lambdas[3], 5)), "\n")
    cat("(Estimated) correlation parameter (alpha):\n")
    cat("                 over uncensored pateints:", signif(object$coefficent$variance$rho.sts,3), "\n")
    cat("                                 over LTS:", signif(object$coefficent$variance$rho.lts,3), "\n")
    cat("\nResiduals:\n", sep="")
    nam <- c("Min", "1Q", "Median", "3Q", "Maobject")
    rq <- structure(quantile(object$coefficent$variance$residuals), names = nam)
    print(rq, digits = digits, ...)
    cat("\n                 Settings and control:\n")
    cat("                            each axis:", object$ndx + object$deg, "- differences of order", object$pord, "\n")
    cat("               convergence tolerance :", format(signif(object$tolerance, 5)), "\n")
    cat("  generalized cross validation (GCV) :", format(signif(object$GCV, 5)), "\n")
    cat("\n")
    invisible(object)
  }
