#' Calculate survival function to fit medical cost trajectory
#'
#' The \code{CostTrajectory_survival} function estimates the hazard function and
#' the corresponding weight matrix required to calculate the design matrix in
#' \code{CostTrajectory} function.
#'
#'
#' @param surv0 vector for the observed survival time of costs.
#' @param status0 vector for the survival status at the observed survival time, death (1) or censored (0).
#' @param ndx vector with the number of internal knots-1 for each axis, default is [5, 5].
#' @param deg vector with the degree of the B-splines for each axis default is [2, 2].
#' @param MON monitor indicator, default is FALSE.
#' @param TOL1 tolerance for convergence criteria, default is 1E-4.
#' @param usecensor a bool to decide whether to use censored cost data, default is TRUE.
#' @param MAX.IT maximum number of iterations, default is 50.
#'
#' @return A list containing survival arguments for the CostTrajectory function
#' @export
#'
#' @examples
#' surv0 <- 1:11
#' status0 <- c(rep(1,10),1)
#' MON <- FALSE; TOL1 <- 1E-4; MAX.IT <- 5
#' ndx <- 5; deg <- 2; pord <- 2
#' lambda <- 1e-5; usecensor <- TRUE
#' CostTrajectory_survival(surv0, status0, MON, TOL1, MAX.IT, ndx, deg, lambda, usecensor)

# library(MASS)
CostTrajectory_survival <- function(surv0, status0, MON, TOL1, MAX.IT,
                                    ndx, deg, lambda = NULL, usecensor = TRUE){
  beta=0; cond_surv=0; var_surv=0
  ntau <- 11
  tau <- seq(0,1,length.out = ntau)
  Y <- surv0
  n <- length(status0)
  nbeta <- ndx+deg
  K <- apply(outer(Y, tau, FUN = function(x,y) 1*(x>y)),1,sum) + 1
  Ytilde <- lapply(1:n, function(i) c(rep(0,K[i]-1), status0[i]))

  o1 <- outer(Y, tau[1:(ntau-1)], FUN=function(x,y) pmin(x,y))
  o2 <- outer(Y, c(tau[3:ntau],2), FUN=function(x,y) pmin(x,y))

  o <- apply(log((o2-o1)/2),1,function(x) x[x>-Inf])
  eo <- lapply(1:n, function(i) c(pmin(tau[2],Y[i]),exp(o[[i]])))
  Bh <- CostTrajectory_bbase(tau, 0, 1, ndx, deg)
  D <- diff(diag(ndx + deg), diff=2)
  DtD <- t(D) %*% D

  beta.new <- rep(1,ndx+deg)
  n2 <- 101; surv00 <- seq(0,1,length.out = n2)
  w <- CostTrajectory_bbase(surv00, 0, 1, ndx, deg)

  if(is.null(lambda)){
    lambdas <- 10^c(-6:4)
    lambda <- select_survival_lambda(Bh, K, eo, Ytilde, w, DtD,
                                     beta.new = NULL,
                                     MON, TOL1, MAX.IT, ndx, deg, n,
                                     lambdas)
  }

  P <- 2*lambda * DtD
  beta <- fit_survival(Bh, K, eo, Ytilde, w, P,
                       beta.new = NULL, MON, TOL1, MAX.IT, ndx, deg, n)
  beta.old <- beta.new
  eBhb <- exp(Bh %*% beta)
  rate <- lapply(1:n, function(i) eBhb[1:K[i]] * eo[[i]])

  if(usecensor){

    marg_surv <- marginal_survival(tau, Bh, eo, rate, surv0, status0, K,
                                   beta, ndx, deg, n, ns=10)

    cond_surv <- conditional_survival(marg_surv, n, nbeta,
                                      surv0, status0, ns=10)
  }
  var_surv <- variance_survival(n, K, Bh, Ytilde, eo, P, beta,
                                surv0, status0)
  return(list(beta=beta, cond_surv=cond_surv, var_surv=var_surv))
}


select_survival_lambda <- function(Bh, K, eo, Ytilde, w, DtD,
                                   beta.new = NULL,
                                   MON, TOL1, MAX.IT, ndx, deg, n,
                                   lambdas = c(0,10^seq(-6,4,1))){
  params <- c(); Devs <- c();
  n2 <- 101; surv00 <- seq(0,1,length.out = n2)

  par(mfrow=c(1,2))
  if(MON){
    plot(NULL, xlim = c(0,1), ylim = c(-6,2),
         xlab = 'Time', ylab = 'log-hazard',
         main = 'Estimated log-hazard function')
    logHazs <- c()
  }
  for(lambda in lambdas){
    P <- lambda * DtD

    beta <- fit_survival(Bh, K, eo, Ytilde, w, P,
                         beta.new, MON=F, TOL1, MAX.IT, ndx, deg, n)

    Bhb <- Bh %*% beta
    lmu <- lapply(1:n, function(i) Bhb[1:K[i]] + log(eo[[i]]))
    Dev <- Reduce('+', lapply(1:n, function(i) sum(Ytilde[[i]] * lmu[[i]] + lmu[[i]])))

    params <- cbind(params, beta)
    Devs <- c(Devs, Dev)
    if(MON){
      par(new=TRUE)
      logHaz <- w %*% beta
      plot((logHaz) ~ surv00, xlab = '', ylab = '',
           xlim = c(0,1), ylim = c(-6,2), type='l')
      logHazs <- cbind(logHazs, logHaz)
    }
  }
  s <- sqrt(apply(params^2,2,sum)); s <- s / s[1]
  p <- ndx + deg
  n <- length(surv0)
  gcv <- (Devs / (n * (1-p*s/n)^2))
  lambda.choose <- lambdas[2:length(lambdas)][which.min(gcv)]

  if(MON){
    par(new=TRUE)
    logHaz <- logHazs[,2:length(lambdas)][,which.min(gcv)]
    plot((logHaz) ~ surv00, xlab = '', ylab = '',
         xlim = c(0,1), ylim = c(-6,2), type='l', col=2)
    plot(gcv~log10(lambdas), type = 'l')
    abline(v = log10(lambda.choose),col=2)
  }

  return(lambda.choose)
}


fit_survival <- function(Bh, K, eo, Ytilde, w, P,
                         beta.new = NULL,
                         MON,TOL1, MAX.IT, ndx, deg, n){
  if(is.null(beta.new))  beta.new <- rep(1,ndx+deg)
  n2 <- 101; surv00 <- seq(0,1,length.out = n2)

  tol <- 1; niter <- 0
  while(tol > TOL1 && niter < MAX.IT){
    beta.old <- beta.new
    eBhb <- exp(Bh %*% beta.old)
    rate <- lapply(1:n, function(i) eBhb[1:K[i]] * eo[[i]])
    hess <-  -Reduce('+', lapply(1:n, function(i)
      Reduce('+',lapply(1:K[i],function(j)
        tcrossprod(Bh[j,]) * rate[[i]][j]))) )
    gradn <-  Reduce('+', lapply(1:n, function(i)
      Reduce('+',lapply(1:K[i],function(j)
        Bh[j,]  * (Ytilde[[i]][j] -rate[[i]][j])))) )
    beta.new <- beta.old - ginv(hess-P) %*% (gradn - P %*% beta.old) # Newton-Raphson
    tol <- max(abs(beta.old - beta.new) / abs(beta.old + 1e-10))
    niter <- niter + 1
  }
  if(MON){
    logHaz <- w %*% beta.new
    plot((logHaz) ~ surv00, type='l',
         xlab = 'Time', ylab = 'log-hazard', main = 'Estimated log-hazard function')
  }

  if(niter > (MAX.IT-1)) {
    warning(paste("parameter estimates did NOT converge in",
                  MAX.IT,
                  "iterations. Increase MAX.IT in control."))
  }
  return(beta.new)
}


marginal_survival <- function(tau, Bh, eo, rate,
                              surv0, status0, K,
                              beta, ndx, deg, n, ns=10){
  ## marginal survival estimate
  ntau <- length(tau); nbeta <- length(beta)
  n <- length(surv0)

  Y0 <- seq(1/ns,1,length.out = ns)
  w <- CostTrajectory_bbase(Y0, 0, 1, ndx, deg)
  K0 <- 2:ntau
  Ytilde <- lapply(1:ns, function(x) c(rep(0,x), 1))

  eBhb <- exp(Bh %*% beta)

  o1 <- outer(Y0, tau[1:(ntau-1)], FUN=function(x,y) pmin(x,y))
  o2 <- outer(Y0, c(tau[3:ntau],2), FUN=function(x,y) pmin(x,y))
  o <- apply(log((o2-o1)/2),1,function(x) x[x>-Inf])
  eo0 <- lapply(1:ns, function(i) c(pmin(tau[2],Y0[i]),exp(o[[i]]))) # exp(o_ik)

  rate0 <- lapply(1:ns, function(i) eBhb[1:K0[i]] * eo0[[i]])
  S0 <- exp(-sapply(rate0, sum)) # marginal survival distribution at 0.1,0.2,...,1
  dS0 <- sapply(1:ns, function(i) -S0[i] * colSums(rate0[[i]] * Bh[1:K0[i],])) # deriv of S wrt beta
  S <- exp(-sapply(rate, sum))
  dS <- sapply(1:n, function(i) -S[i] * colSums(rate[[i]] * Bh[1:K[i],])) # deriv of S wrt beta

  return(list(surv0 = S0, surv = S,
              deriv_surv0 = dS0, deriv_surv = dS))
}


conditional_survival <- function(marg_surv, n, nbeta,
                                 surv0, status0, ns=10){
  ## conditional survival estimate

  S0 <- marg_surv$surv0
  S <- marg_surv$surv
  dS0 <- marg_surv$deriv_surv0
  dS <- marg_surv$deriv_surv

  id.cen <- which(surv0 < 1 & status0 == 0)
  surv00 <- surv01 <- seq(1/ns, 1, length.out = ns); surv00[ns] <- 1.1
  prob.cond <- surv0.cond <- matrix(-99, ns+1, n)
  dprob.cond <- array(0, dim = c(n, nbeta, ns+1))
  for(x in id.cen){
    # calculate derivative Pim(beta)
    scond <- (surv00 > surv0[x]) *  S0
    idx0 <- which(scond==0)
    nidx0 <- length(idx0)
    idx0 <- ifelse(nidx0 == 0, 0, idx0[nidx0])
    scond <- append(scond, S[x], after=idx0) / S[x]
    pcond <- c(-diff(scond), scond[ns+1])
    pcond[pcond<0] <- 0
    dcond <- append(surv01, surv0[x], after=idx0)
    dcond <- dcond + c(diff(dcond) / 2, .1)
    prob.cond[,x] <- pcond
    surv0.cond[,x] <- dcond
    # calculate derivative d Pim(beta) / d betap
    dscond <- dS0 - dS[,x]
    dscond <- unname(data.frame(append(data.frame(dscond),
                                       list(X0=dS[,x]), idx0)))
    dpcond <- cbind(t(-diff(t(dscond))), dscond[,ns+1])
    dprob.cond[x,,] <- round(dpcond, 5)
  }

  colnames(surv0.cond) <- colnames(prob.cond) <- paste0('id_',1:n)

  dprob.cond <- aperm(dprob.cond, c(2,3,1))
  surv0.prob.cond <- list(surv0 = surv0.cond,
                          prob = prob.cond,
                          dprob = dprob.cond)
  return(surv0.prob.cond)
}


variance_survival <- function(n, K, Bh, Ytilde, eo, P, beta,
                              surv0, status0){
  # calculate sandwich variance estimator

  eBhb <- exp(Bh %*% beta)
  rate <- lapply(1:n, function(i) eBhb[1:K[i]] * eo[[i]])

  gradn <- sapply(1:n, function(i)
    Reduce('+',lapply(1:K[i],function(j)
      Bh[j,]  * (Ytilde[[i]][j] -rate[[i]][j])))) #- c(P %*% beta)

  hess <- Reduce('+',lapply(1:n, function(i)
    Reduce('+',lapply(1:K[i],function(j)
      tcrossprod(Bh[j,]) * rate[[i]][j])))) + P

  return(list(gradn = gradn, hess = hess))

}
