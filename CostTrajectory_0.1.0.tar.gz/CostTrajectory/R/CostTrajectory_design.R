#' Calculate design matrix to fit medical cost trajectory
#'
#' The \code{CostTrajectory_design} function generate the design matrix
#' for \code{CostTrajectory} function.
#'
#' @param time vector for the measurement time of costs.
#' @param surv vector for the observed survival time of costs. The length of '"surv"'  should be the same as the number of observations.
#' @param cost vector for the observed monthly costs.
#' @param id vector for the identifier of each subject. The length of '"id"'  should be the same as the number of observations.
#' @param status vector for the survival status at the observed survival time, death (1) or censored (0).
#' @param ndx vector with the number of internal knots-1 for each axis, default is [5, 5].
#' @param deg vector with the degree of the B-splines for each axis default is [2, 2].
#' @param pord vector with the order of differences for each axis. Default: [2, 2].
#' @param lambda vector with smoothing parameters, possibly three for axis (optional).
#' @param coefstart an optional matrix of starting coefficients.
#' @param usecensor a bool to decide whether to use censored cost data, default is TRUE.
#' @param control a list of control parameters. See \code{Details}.
#' @param correlation a character string specifying the correlation structure. The following are permitted: '"independence"', '"compound"' and '"ar1"'
#'
#' @return A list containing design arguments for the CostTrajectory function
#' @export
#'
#' @examples
#' time <- Reduce('c',sapply(1:11, function(x) 1:x))
#' surv <- id <- Reduce('c',sapply(1:11, function(x) rep(x,x)))
#' cost <- (time-5)^2*surv/10+rnorm(66,10,1)
#' status <- c(rep(1,55), rep(0,11))
#' MON <- FALSE; TOL1 <- 1E-4; MAX.IT <- 5
#' ndx <- 5; deg <- 2; pord <- 2
#' lambda <- 1e-5; usecensor <- FALSE
#' CostTrajectory_design(time/surv, surv, cost, id, status,
#'                       ndx, deg, lambda, usecensor, surv.out = 0)


CostTrajectory_design <- function(time, surv, cost, id, status,
                                  ndx = 5, deg = 2,
                                  usecensor = TRUE, surv.out){
  ## B-splines basis ordinate (x, y)
  xmax <- ymax <- 1.01
  xmin <- ymin <- -0.01
  nbeta <- ndx + deg
  x <- time
  y <- surv
  z <- cost
  # short term survivors

  idx.sts <- which(status == 1)
  x.sts <- x[idx.sts] /  y[idx.sts]
  y.sts <- y[idx.sts]
  z.sts <- z[idx.sts]
  id.sts <- id[idx.sts]
  status.sts <- status[idx.sts]
  m.sts <- length(idx.sts)
  Bx.sts <- CostTrajectory_bbase(x.sts, xmin, xmax, ndx, deg)
  By.sts <- CostTrajectory_bbase(y.sts, ymin, ymax, ndx, deg)
  B.sts <- kronecker(matrix(1, ncol = nbeta), Bx.sts) *
    kronecker(By.sts, matrix(1, ncol = nbeta))

  bases.name.sts <- paste0('basis_',1:ncol(B.sts))
  colnames(B.sts) <- bases.name.sts

  # long term survivors
  idx.lts <- which(status == 0 & y == 1)
  x.lts <- x[idx.lts]
  y.lts <- y[idx.lts]
  z.lts <- z[idx.lts]
  id.lts <- id[idx.lts]
  status.lts <- status[idx.lts]
  Bx.lts <- CostTrajectory_bbase(x.lts, xmin, xmax, ndx, deg)
  B.lts <- Bx.lts
  bases.name.lts <- paste0('basis_',1:ncol(B.lts))
  colnames(B.lts) <- bases.name.lts

  # combine results for sts and lts
  x.unc <- c(x.sts, x.lts)
  y.unc <- c(y.sts, y.lts)
  z.unc <- c(z.sts, z.lts)
  id.unc <- c(id.sts, id.lts)
  status.unc <- c(status.sts, status.lts)
  B.unc <- as.matrix(bdiag(B.sts, B.lts))

  # calculate conditional survival probability weights
  # collect data for censored patients
  if(!usecensor){
    x <- x.unc
    y <- y.unc
    z <- z.unc
    id <- id.unc
    status <- status.unc
    B <- B.unc
    dB <- surv.out <- 0
  }else{
    # patients censored prior to tau
    idx.cen <- which(status == 0 & y < 1)
    x.cen <- x[idx.cen]
    y.cen <- y[idx.cen]
    z.cen <- z[idx.cen]
    id.cen <- id[idx.cen]
    status.cen <- status[idx.cen]

    surv.cond <- surv.out$cond_surv$surv0
    prob.cond <- surv.out$cond_surv$prob
    dprob.cond <- surv.out$cond_surv$dprob

    ncen <- length(idx.cen)
    nbeta <- ndx+deg
    nsurv <- nrow(surv.cond)
    # get design matrix for each subject i=1,...,n; for survival time m=1,...,11

    B.cen.stsm <- foreach(j = 1:(nsurv-1)) %do% {
      Bx.cen <- CostTrajectory_bbase(x.cen / surv.cond[j, id.cen],
                                 xmin, xmax, ndx, deg)
      By.cen <- CostTrajectory_bbase(surv.cond[j, id.cen],
                                 ymin, ymax, ndx, deg)
      kronecker(matrix(1, ncol = nbeta), Bx.cen) *
        kronecker(By.cen, matrix(1, ncol = nbeta))
    }

    B.cen.sts <- foreach(j = 1:(nsurv-1), .combine = '+') %do% {
      prob.cond[j, id.cen] * B.cen.stsm[[j]]
    }
    Bx.cen <- CostTrajectory_bbase(x.cen, xmin, xmax, ndx, deg)
    B.cen.lts <- prob.cond[nsurv, id.cen] * Bx.cen
    B.cen <- cbind(B.cen.sts, B.cen.lts)

    # get derivative of design matrix wrt beta (p=1,...,nbeta) for each subject i=1,...,n
    dB.cen.sts <- foreach(j = 1:(nsurv-1), .combine = '+') %do% {
      dprob.cen <- dprob.cond[, j, id.cen]
      sapply(1:ncen, function(i) outer(dprob.cen[,i],
                                       B.cen.stsm[[j]][i,]),
             simplify = 'array')
    }
    dprob.cen.lts <- dprob.cond[, nsurv, id.cen]
    dB.cen.lts <- sapply(1:ncen, function(i) outer(dprob.cen.lts[,i],
                                                   Bx.cen[i,]),
                         simplify = 'array')

    dB.cen <- array(0, dim = c(nbeta, nbeta * (nbeta+1), ncen))
    dB.cen[,1:(nbeta^2),] <- dB.cen.sts
    dB.cen[,(1:nbeta)+(nbeta^2),] <- dB.cen.lts
    dB <- dB.cen
    x <- c(x.unc, x.cen)
    y <- c(y.unc, y.cen)
    z <- c(z.unc, z.cen)
    id <- c(id.unc, id.cen)
    status <- c(status.unc, status.cen)
    B <- rbind(B.unc, B.cen)

  }
  colnames(B) <- paste0('basis_',1:ncol(B))
  out <- list(x=x, y=y, z=z,
              id=id, status=status,
              B=B, dB=dB,
              surv = surv.out)
  return(out)
}
