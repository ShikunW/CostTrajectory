#' Simulate longitudinal medical cost trajectory
#'
#' The \code{CostTrajectory_simulate_data} function simulate longitudinal
#' medical cost data w/o error to train / test the model
#'
#' @param n number of subjects. maximum follow-up month if for testing (test=TRUE).
#' @param seed seed of random error generator for training (test=FALSE).
#' @param MON a \code{control} bool value for monitor status, default is FALSE.
#' @param test a bool value to indicate whether to simulate train (=FALSE) /
#' test (=TRUE) data. Train data has multivariate normal error and weibull survival.
#' Test data is observed by month without error.
#'
#' @return A data frame containing valid input for \code{CostTrajectory} function.
#' @export
#'
#' @examples
#' CostTrajectory_simulate_data(n=10, test=T)

# library(splines)
# library(Matrix)
# library(survival)
# library(MASS)
# library(simstudy)
CostTrajectory_simulate_data <- function(n = 1000, seed = 123, MON = F, test = F){
  #n = 500; gamma = log(.01); rho = 0.2; prop.zero = 0; seed = 123; test = F; dist = 1; fig = T
  set.seed(seed)
  # generate survival data
  if(test){
    dat.death <- cbind(seq(1 ,n, by=1),rep(999,n))
  }else{
    scale <- 1; shape <- 2
    surv <- rweibull(n, shape=shape, scale=1/scale)
    censor <- runif(n,0,2)
    dat.death <- cbind(surv, censor)
    dat.death <- pmax(round(dat.death * 100), 1)
  }


  dat.surv <- apply(dat.death,1,function(x) min(c(x, 100)))
  dat.status <- apply(dat.death,1,function(x)1*(x[1] <= x[2] & x[1] <= 100))
  nn <- as.integer(floor(dat.surv))
  dat.tmp <- data.frame(id = rep(1:n,nn),
                        surv = rep(dat.surv,nn),
                        death = rep(dat.death[,1],nn),
                        time = unlist(sapply(nn,function(x)1:x)),
                        status = rep(dat.status,nn))

  ###! parametric presentation
  traj.true <- function(t,s) {
    t <- t/100; s <- s/100
    (((s<=1/4)*(4/s*(t-s/2)^2 +1.25-s))+
      ((s<=1)*(s>1/4)*((t<=1/4)*12*(t-1/4)^2 +.5+
                (t>s-1/4)*12*(t-s+1/4)^2))+
        ((s>1)*((t<=1/3)*9*(t-1/3)^2+.25)))*10}

  dat.tmp$Y <- traj.true(dat.tmp$time, dat.tmp$death)

  if(!test){
    for(i in 1:n){
      idxi <- which(dat.tmp$id==i)
      ni <- length(idxi)
      timei <-dat.tmp$time[idxi]
      Yi <- dat.tmp$Y[idxi]
      if(dat.tmp$death[idxi[1]] <= 1){
        rho <- 0.2
        Ri <- matrix(rho,ni,ni)
        diag(Ri) <- 1
        varYi.sqrt <- diag(ni)
        diag(varYi.sqrt) <- sqrt(exp(0.01))
        Sigma <- (varYi.sqrt) %*% Ri %*% (varYi.sqrt)
        err <- mvrnorm(1,mu = rep(0,ni),Sigma = Sigma) * (dat.tmp$Y[idxi] > 0)
        dat.tmp$Y[idxi] <- Yi + err

      }else{
        rho <- 0.1
        Ri <- matrix(rho,ni,ni)
        diag(Ri) <- 1
        varYi.sqrt <- diag(ni)
        diag(varYi.sqrt) <- sqrt(exp(0.01))
        Sigma <- (varYi.sqrt) %*% Ri %*% (varYi.sqrt)
        err <- mvrnorm(1,mu = rep(0,ni),Sigma = Sigma) * (dat.tmp$Y[idxi] > 0)
        dat.tmp$Y[idxi] <- Yi + err
      }
    }
  }
  # dat.tmp$Y <- dat.tmp$Y*rbinom(nrow(dat.tmp), p=1-prop.zero, 1)/(1-prop.zero)
  # plot data
  if(MON){
    plot(NULL, xlim = c(0,100), ylim = c(0,20), xlab = 'Time', ylab = 'Cost')
    for(i in 1:100){
      dati <- dat.tmp[dat.tmp$id==i,]
      lines(dati$time,dati$Y,col = floor(dati$death[1]))
    }
  }
  return(dat.tmp)
}

CostTrajectory_test_design <- function(ndx, deg, n=101){
  xmin <- ymin <- -0.01; xmax <- ymax <- 1.01
  dat.test0 <- CostTrajectory_simulate_data(n=n, test=T)
  dat.test <- dat.test0[dat.test0$surv > 0,]
  dat.test$time <- dat.test$time / 100
  dat.test$surv <- dat.test$surv / 100
  dat.test$death <- dat.test$death / 100
  dat.test.sts <- dat.test[which(dat.test$death<=1),]
  dat.test.lts <- dat.test[which(dat.test$death>1),]
  Bxi.sts <- CostTrajectory_bbase(dat.test.sts$time / dat.test.sts$surv, xmin, xmax, ndx, deg)
  Byi.sts <- CostTrajectory_bbase(dat.test.sts$surv, ymin, ymax, ndx, deg)
  Bi.sts <- kronecker(matrix(1, ncol = ndx+deg), Bxi.sts) *
    kronecker(Byi.sts, matrix(1, ncol = ndx+deg))
  Bi.lts <- CostTrajectory_bbase(dat.test.lts$time, xmin, xmax, ndx, deg)
  Bi <- bdiag(Bi.sts, Bi.lts)
  list(B=Bi, data = dat.test0)
}
