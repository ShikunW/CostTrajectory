#' Calculate population mean longitudinal medical cost trajectory
#'
#' The \code{CostTrajectory_PopulationMean} function produces the pointwise averaged
#' estimate based on data from uncensored patients and long-term survivors.
#'
#' @param dat a data frame storing cost and survival data.
#'
#' @return A data frame of estimated cost trajectory
#' @export
#'
#' @examples
#' data <- CostTrajectory_simulate_data(n=50)
#' CostTrajectory_PopulationMean(data)
#'
CostTrajectory_PopulationMean <- function(dat){
  tau <- max(dat$surv)
  s.list <- 1:tau
  dat.unc <- subset(dat,status == 1)
  tmp <- data.frame(
    surv = unlist(sapply(s.list,function(x)rep(x,x))),
    death = unlist(sapply(s.list,function(x)rep(x,x))),
    time = unlist(sapply(s.list,function(x)1:x)))
  for(i in 1:nrow(tmp)){
    dati <- dat.unc[ceiling(dat.unc$surv) == tmp$surv[i] & dat.unc$time == tmp$time[i],]
    tmp$Y[i] <- mean(dati$Y,na.rm=T)
  }
  dat.tau <- subset(dat, status==0 & surv == 1)
  tmp.extra <- data.frame(
    surv = rep(tau,tau),
    death = rep(tau+1,tau),
    time = 1:tau)
  for(i in 1:nrow(tmp.extra)){
    dati <- subset(dat,surv == tmp.extra$surv[i] & status == 0 & time == tmp.extra$time[i])
    tmp.extra$Y[i] <- mean(dati$Y)
  }
  rbind(tmp,tmp.extra)

}
